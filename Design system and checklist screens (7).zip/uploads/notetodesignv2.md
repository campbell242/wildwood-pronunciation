# Back to Claude Design — section 5 built, plus 1l for your pass

**Attachments:** `06-parent-settings-new-cards.png`, `07-excuse-a-night-modal.png`
(the two you asked for), and `A-checklist-locked-slot.png` (5a as built, for
confirmation).

## Built as specced — nothing to review unless the screenshot surprises you

- **5a**: locked slot (flat iron `#6f6f6f`, 3px `#4a4a44`, 14px inset square, no
  bevel, not tappable) and the iron `MORNING CHECK` pill under the hint. The
  sentence left the hint voice; the gold +100 chip is untouched; 1k unchanged.
- **The three §2 rows**: "+N" rolls from 0 at 120ms in 10 × 50ms steps; the
  counter's coin answers each of the 8 landings (1.18 → 1, 120ms); "Great job,
  Haley!" and the streak line fade up 8px at 1600ms. Reduced motion: no roll,
  no landings, closing lines still arrive as a plain fade.
- **Auto-quiet**: ×0.5 from window start, ×0.25 after the handoff, alarm exempt.
  Measured in the built app: .05 blips / .07 last-required / .06 ask before the
  handoff, .03 after.

## Two questions

1. **The locked slot has a state the addendum doesn't cover: checked.** A parent
   can tick the sleep item in the morning-verify block before approving, and
   Haley may reopen the checklist before that approval lands. I kept the iron
   ground and put a white ✔ where the inset square goes, so the fact shows
   without the row looking undoable. Say if you'd rather it stay a plain inset
   square regardless.
2. **Does the award celebration keep the ×0.25?** "Nothing after the handoff is
   Haley acting" is true of everything except the one thing that is hers — the
   celebration release. In the normal flow the parent approves the next morning,
   outside the window, so it plays at full gain; but if they approve the same
   night, her collection tap plays the arpeggio at a quarter gain. Options:
   leave it (quiet is right at 10pm), or exempt the award/redemption cues from
   the post-handoff step and keep them at ×0.5.

## Context for 06 — parent settings (1l)

Cards top to bottom, all in the iron/neutral parent language, all built without
a design source:

- **ROUTINES** — "Nighttime · every day" with the window start as an editable
  value: `7:00 PM ✎`.
- **STREAK** — "Sleepover or special night?" · `Excuse a night ✎`.
- **SOUND** — two rows, "All sounds" and "Timer alarm", each with an ON/OFF
  pill, plus helper text: *"The alarm has its own switch so the timer can stay
  audible with everything else off. Sounds automatically play quieter during and
  after the nighttime routine."*
- **REWARDS + COINS** — "Base award (each routine) `204 ✎`", "Balance 🪙 0
  `+/− adjust`", "Redemption at 1,720" with the redeem button showing
  `Redeem · 1,720 to go` when it's short.
- **PARENT PIN** — "4-digit PIN `···· ✎`".

Three choices in there I made blind and would take a ruling on:

- **The ON pill is green (`#57a636`) — Haley's material inside the parent area.**
  OFF is stone. Green was the only thing that read unambiguously as "live", but
  it's the one place the parent zone borrows her colour. Iron-on/iron-off with a
  brighter inset would keep the zone pure if you prefer.
- **Editable values are green text with a ✎** (`7:00 PM ✎`, `204 ✎`,
  `Excuse a night ✎`) — the same borrow, at text scale.
- **Helper copy is mine, not yours.** The sound helper above and
  "tap the number to type an exact amount" in 1k are the two lines that explain
  mechanics; if the parent area gets a voice, they're where it starts.

## Context for 07 — the excuse modal

Title "Excuse a night". Body: *"Sleepover, travel, sick day — the streak skips
the night instead of breaking. No coins are awarded."* Then two options and a
cancel: `Tonight · Aug 17` and `Last night · Aug 16 · already settled` — the
second disabled, because that night was already approved or closed. The disabled
state is stone with the reason appended to the label rather than a separate
error line; no red anywhere, per the tone rules. One tap confirms, consistent
with "Close for today".
