# Claude Design Brief: Haley's Routine & Minecraft Coin App

You are designing the visual system and key screens for a personal app that runs full-screen in portrait on a dedicated Android phone. The user is Haley, a 10-year-old girl. This is a household app for one child; there are no intellectual-property constraints, and the design should be unapologetically Minecraft-themed because Haley loves Minecraft and the app's coins redeem for real Minecoins.

Your job here is **visual design and screen-level UX only**. Do not implement application logic, data persistence, timers that actually run, or state machines. Behavior will be built later in Claude Code using your design as the visual source of truth. Screens may use plausible static/sample data.

---

## 1. What the App Does (Context Only)

You need just enough product context to design honest screens:

* Haley completes recurring behavioral checklists (a **Morning Routine** on weekdays and a **Nighttime Routine** every day). Each checklist has required items and optional bonus items worth extra coins.
* When she finishes the required items, she requests **parent approval**. A parent unlocks a parent area with a 4-digit PIN and approves the routine, awarding **gold coins** (suggested amount shown, editable). The parent can also send the routine back or close it for the day.
* Coins accumulate toward a redemption goal of **1,720**, at which point a parent redeems them for real Minecraft coins. The balance can exceed 1,720.
* Streaks recognize consecutive completions. Streaks are purely positive; a broken streak is never dramatized.
* The app includes a large, always-accessible **clock** and a simple **countdown timer** Haley controls (presets: 5, 10, 15, 30 minutes; free-form entry in whole minutes; big numeric countdown like **08:42** — no pie-chart or shrinking-circle visualizations).
* Haley can personalize an **avatar** and a **theme variant** (described below).

Tone requirements: fun, modern, slightly game-like, encouraging, and never babyish. Emphasize what Haley can do next. No red failure states, no punitive or shame-based styling, ever.

---

## 2. Visual Direction: Minecraft UI Language

Theme the **interface language**, not the terrain:

* Pixel aesthetic with chunky, beveled buttons in the style of Minecraft menu buttons.
* Slot/inventory-style framing where it helps (checklist items, avatar picker).
* A Minecraft-style pixel font (Monocraft or similar).
* Block textures (dirt, stone, planks, iron) used only as **accents**: headers, card borders, dividers, and the parent-area entrance (which may read as an "iron door"). Backgrounds behind text and checklists stay calm and high-contrast.

Do **not** cover screens in busy grass/dirt texture collages. Readability and low cognitive load win every conflict with theming.

### Typography rule

* Pixel font: headings, numbers, the clock, the countdown, buttons, coin amounts.
* Clean readable sans-serif: checklist instructions and any sentence-length text.
* The clock must be readable from across a small room.

### Coins

Style the balance as gold, Minecoin-like coins (not emeralds). The coin treatment is an important motif but the app should not look like a casino.

### Progress

Render progress toward 1,720 as a **Minecraft XP bar** (green, segmented, pixel-styled) with the numeric balance alongside (for example, **1,240 / 1,720**). If the balance exceeds 1,720, the bar stays full while the number keeps climbing.

### Positive feedback

Model accomplishment feedback on Minecraft's **advancement toast**: a short popup that slides in and dismisses itself. Used for routine completion, coin awards, and streak milestones. Coin awards may add a brief coin animation. Keep celebrations short and non-blocking.

### Tone protection

Minecraft has creepers, TNT, and damage hearts. **None of that may appear in failure-adjacent states.** A routine sent back or closed for the day gets calm, neutral styling — no explosions, no lost hearts, no red damage flashes.

---

## 3. Customization

Design two child-facing personalization choices (no PIN required):

1. **Avatar**: a fixed set of pixel-art Minecraft characters and mobs (Steve, Alex, creeper, axolotl, cat, panda, and a few others). The avatar appears somewhere pleasant and persistent, such as the home header.
2. **Theme variant**: a small curated set styled after Minecraft dimensions/biomes — Overworld (default), Nether, End, optionally Ocean or Cherry Grove. Each variant is a designer-curated accent palette wearing a Minecraft costume: it changes accent colors, header treatment, and small decorative touches only. Every variant must preserve full text/background contrast (Nether is warm-accented, not dark red on black), the gold-coin treatment, the XP-bar treatment, and the layout.

No free-form color picker, no image upload, no unlockable or purchasable cosmetics.

---

## 4. Screens to Design

Design these screens plus the navigation model that connects them. You own the information architecture; choose whatever navigation (tabs, cards, persistent header, bottom nav) best serves a distractible 10-year-old. The clock should be highly accessible throughout, and a running timer should stay visible.

1. **Home**: current time, coin balance with XP-bar progress, Haley's avatar, the currently relevant routine surfaced prominently with its status, and a clear next action. Also design the empty/nothing-due state.
2. **Active routine / checklist**: required items and bonus items (bonus items show their coin values), clear checked/unchecked states, item instructions, and the "ask a parent to check" action that appears when required items are done. Show at least these status treatments: in progress, ready for parent review, sent back (neutral), waiting/approved.
3. **Timer**: presets (5/10/15/30), free-form minute entry, and the running state with a large numeric countdown, pause/resume/cancel, and the expired alert state.
4. **Parent area**: the subtle entrance from the child UI, the PIN pad, and the approval screen — suggested coin amount (base plus completed bonuses) prominently shown and editable, with Approve & Award, Send Back, and Close for Today actions. Also a simple settings view (routine times, base rewards, manual coin add/subtract, redemption) and a visible lock control. Include a checkbox-style verification treatment for items a parent confirms the next morning (bedtime items Haley couldn't check because the phone leaves her room).
5. **Coin award moment**: the celebration when a parent approves — toast, coin animation, XP bar advancing.
6. **Customization picker**: avatar selection and theme variant selection, inventory/slot styled.

Design for portrait, large tap targets, immediate feedback, and very low cognitive load throughout.

---

## 5. Deliverable

A cohesive design system and the screens above, ready to hand off to Claude Code for implementation. Prioritize: (1) a distractible 10-year-old, (2) very fast everyday use, (3) positive reinforcement, (4) minimal cognitive load, (5) easy parent approval.
