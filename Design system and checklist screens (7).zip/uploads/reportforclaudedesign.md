# Report for Claude Design — deviations & interpretations from the handoff

*Current as of the latest build (the sleep item is now a required item that
keeps its own +100 — see item 11, which replaces the earlier version of this
point). References are to the handoff docs and screen/section IDs; numbered
PNG attachments illustrate the items marked with 📎.*

## Spec conflicts I resolved — please confirm or re-spec

1. **§4 "Timer start: presets cross-fade out" — skipped.** Starting the
   timer replaces the entire screen, and your own global rules say "no
   animation may delay a screen change" and "screen changes are instant."
   The bar-snap ("loaded") was kept. If the cross-fade matters, re-spec it
   as elements *within* one persistent screen.
2. **Sound rule "auto-quiet during the Nighttime Routine window and after
   it" — read as half-gain, not mute.** The routine *opens* the window
   (19:00), so every core cue — the pentatonic run, the ask, the award —
   happens inside it; muting would silence the app's signature sounds every
   single night. Implemented: all cues at ×0.5 gain from windowStart to
   midnight, alarm exempt at full gain. If mute was intended, say so and
   I'd argue for it applying only after the phone handoff.
3. **§1's 200ms pip beat can't fire literally.** 📎 04. The pip row lives
   on the Home routine card; check-off happens on the routine screen where
   no pips exist. Implemented: newly-green pips flip (scaleX from left,
   160ms, 80ms stagger) the first time the card is next seen, once, tracked
   per-pip. Alternative if preferred: add a pip row to the routine screen
   (would change 1d/1e).

## Spec'd but never commissioned

The three §2 rows outside all three phases: "+55 rolls from 0" (120ms,
500ms stepped), the counter coin's per-landing scale reaction (1.18→1,
120ms), and the 1600ms "Great job" fade-up. Unbuilt; quick adds if wanted.

## Small renderings design should know about

4. **Milestone stars**: 📎 05. "Three 6px pixel stars" rendered as 10px
   Pixelify ★ glyphs (≈6px star body). If a drawn 6px star sprite is
   preferred, add it to the icon pack.
5. **Daily streak "count rolls to its new number"**: the count changes with
   the ★ pulse; no odometer-style digit roll was built (extensions are +1,
   so a roll is one step). Spec digit treatment if a visible roll is wanted.
6. **Non-square icons (NEW_ICONS)**: 📎 01 (rat and phone rows). Rat
   (40×22) and phone (24×40) are rendered via `object-fit: contain` inside
   the shared 28px row footprint — proportions preserved, never resampled.
   Worth stating in the icon-pack sizing rules since the original 37 are
   all square.
7. **Sent-back banner animates on arrival even on a screen mount** (per the
   §4 table), which is the one exception to the "nothing animates on mount"
   pattern used everywhere else. Deliberate; flagging the inconsistency.

## Pre-existing deviations from earlier handoffs, still in effect

8. **Running-timer screen has a labeled "‹ Home" back affordance** 📎 08
   (1h shows none) — without tabs on that screen, there was no way to
   leave a running timer except cancelling it.
9. **The "Approved!" banner treatment (1f) is never rendered** — approval
   flows straight to the handoff (1o) and award (1m) screens, so the state
   it describes doesn't exist on the checklist.
10. **Checked rows keep their hint text** (1d shows hints on checked rows;
    1e drops them — read as sample-data variance, 1d behavior kept).

## NEW since the last report — the family made the sleep item required

11. **A required row now carries a coin value — a pattern 1d/1e never
    anticipated.** 📎 01, 02, 03. The +100 "In bed, lights out, stay in
    bed" item was moved out of the gold "BONUS COINS" section into the
    required (ink-bordered, cream) section, directly after the phone
    handoff, *keeping* its +100. Concretely, three renderings deviate from
    the mockups:
    - **Checklist (1d/1e)** 📎 01: a coin chip (`+100`, gold #8a6200 on
      cream #fffdf6) now appears on a required row, plus the subline "A
      grown-up checks this one in the morning" — the mockups only show
      chips on gold bonus rows. I reused the bonus rows' chip treatment
      unchanged. If design wants a distinct treatment for
      "required-with-value" (different chip color, a lock glyph, a special
      border), spec it — there's exactly one such row today.
    - **Parent review (1k)** 📎 02, 03: the sleep row renders in the
      required list with a toggleable checkbox (same slot control as the
      parent-verified bonus rows had) and its +100. Unchecked, the
      suggested award reads 244; one tap flips it to 344.
    - **Copy change in 1k's award editor**: "AWARD · base X + bonus Y"
      became "**base X + earned Y**", since the earned coins now include a
      required item, not just bonuses.
    Behavior for context: the item is mandatory in placement but
    parent-verified next morning, so it never gates "Ask a parent" or the
    Home pips, and an unmet night auto-docks exactly 100 from the
    suggestion with no parent math.

## Parent-area growth (no design source exists for these)

12. **Parent settings (1l) has grown four in-system-styled additions
    design hasn't reviewed**: 📎 06, 07. A STREAK card ("Excuse a night"
    modal — sleepover/travel nights skip the streak, no coins), a SOUND
    card (All sounds + Timer alarm toggles), a PIN-change row, and the
    verify block's confirm now names its coin amount. All follow the
    iron/neutral parent language — worth a design pass if 1l is ever
    revised.
13. **Cherry Grove and Ocean theme variants** use adjusted token choices
    for contrast (dark text on pink like the gold-button convention;
    Ocean's deeper #2e6e8f swatch as its primary) — the handoff's swatch
    trios are decorative; the mapping to buttons was mine.

## Attachment index

| File | Shows |
|---|---|
| 01-checklist-required-sleep-plus100.png | Checklist: +100 sleep row in the required section (also: rat/phone non-square icons in place) |
| 02-parent-review-autodock-244.png | Parent review: sleep unchecked, suggestion auto-docked to 244, "base 204 + earned 40" |
| 03-parent-review-confirmed-344.png | Parent review: sleep confirmed, suggestion 344, "base 204 + earned 140" |
| 04-home-card-pip-flip.png | Home card pips mid-flip (the deferred §1 pip beat) |
| 05-home-milestone-streak.png | 7-day milestone: toast + gold chip flash (star glyph treatment) |
| 06-parent-settings-new-cards.png | Parent settings: STREAK + SOUND cards, PIN row |
| 07-excuse-a-night-modal.png | "Excuse a night" modal copy and options |
| 08-timer-home-back-label.png | Running timer with the "‹ Home" back affordance |
